package cl.desafiolatam.transformerapp;

public interface TransformerView {
    void showDateResult();
    void showMathResult();
}
